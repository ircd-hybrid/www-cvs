Extract this zip file in C:\.  The path C:\ircd is hard-coded
into the binary.

