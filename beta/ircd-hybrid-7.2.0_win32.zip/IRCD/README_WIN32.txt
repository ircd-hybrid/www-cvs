Extract this zip file in C:\.  The path C:\ircd is hard-coded
into the binary.  If you want a different path, you will need
to download the source code and recompile with BCC or MSVC.
The source code includes the batch file contrib\win32build.bat
to help you compile with BCC or MSVC.  You can download the
GPL source code from http://www.ircd-hybrid.org.

Please report bugs to bugs@ircd-hybrid.org

